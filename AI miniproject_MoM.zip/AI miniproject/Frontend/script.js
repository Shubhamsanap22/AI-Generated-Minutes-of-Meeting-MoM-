// script.js
// Reads .txt file, sends its text to FastAPI backend, displays a cleaned, formatted summary.

document.addEventListener("DOMContentLoaded", () => {
  const fileInput = document.getElementById("textInput");
  const summaryBox = document.getElementById("summaryBox");
  const statusText = document.getElementById("statusText");
  const generateBtn = document.getElementById("generateBtn");

  const BACKEND_URL = "http://127.0.0.1:8000/summarize";

  generateBtn.addEventListener("click", () => {
    if (!fileInput.files || fileInput.files.length === 0) {
      summaryBox.textContent = "Please upload a .txt file first.";
      statusText.textContent = "";
      return;
    }

    const file = fileInput.files[0];

    if (!file.name.toLowerCase().endsWith(".txt")) {
      summaryBox.textContent = "Invalid file type. Please upload a .txt file.";
      statusText.textContent = "";
      return;
    }

    const reader = new FileReader();

    reader.onload = async function (e) {
      const text = e.target.result || "";
      if (!text.trim()) {
        summaryBox.textContent = "The file appears to be empty.";
        statusText.textContent = "";
        return;
      }

      summaryBox.textContent = "";
      statusText.textContent = "Sending to backend...";

      try {
        const res = await fetch(BACKEND_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ text }),
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          summaryBox.textContent =
            "Error from backend: " + (errData.detail || res.statusText);
          statusText.textContent = "";
          return;
        }

        const data = await res.json();
        if (data.summary) {
          // Use formatted HTML instead of raw text
          summaryBox.innerHTML = formatSummary(data.summary);
          statusText.textContent = "Summary generated";
        } else {
          summaryBox.textContent =
            "Backend did not return a summary. Please check logs.";
          statusText.textContent = "";
        }
      } catch (err) {
        console.error(err);
        summaryBox.textContent =
          "Could not connect to backend. Is FastAPI running?";
        statusText.textContent = "";
      }
    };

    reader.onerror = function () {
      summaryBox.textContent = "Error reading file. Please try again.";
      statusText.textContent = "";
    };

    reader.readAsText(file);
  });
});

/**
 * Clean and format the summary:
 *  - remove '*' characters
 *  - keep bullets clean
 *  - make section titles bold
 */
function formatSummary(raw) {
  if (!raw || typeof raw !== "string") return "No summary.";

  const lines = raw.split(/\r?\n/);

  const formattedLines = lines.map((line) => {
    // Remove all '*' characters
    let clean = line.replace(/\*/g, "").trim();

    if (!clean) return "";

    const lower = clean.toLowerCase();

    // Identify headings and make them bold
    const isHeading =
      lower.startsWith("short summary") ||
      lower.startsWith("summary:") ||
      lower.startsWith("key decisions") ||
      lower.startsWith("decisions") ||
      lower.startsWith("action items") ||
      lower.startsWith("actions") ||
      lower.startsWith("important discussion points") ||
      lower.startsWith("discussion points");

    if (isHeading) {
      // Ensure colon at the end for neatness
      if (!clean.endsWith(":")) clean = clean + ":";
      return `<strong>${clean}</strong>`;
    }

    // Normalize bullets: if line starts with dash or bullet, convert to "• "
    clean = clean.replace(/^[-•]\s*/, "• ");

    return clean;
  });

  // Join with <br> so line breaks show in HTML
  return formattedLines.join("<br>");
}
