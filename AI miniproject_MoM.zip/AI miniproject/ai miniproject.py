"""
BiLSTM Sentence Classifier for Meeting Transcripts
-------------------------------------------------

What this script does:

1. Load the dataset (test_df.csv).
2. Preprocess transcripts:
   - Extract "Speaker X:" prefix.
   - Clean text (remove [laughter], fillers, extra spaces).
   - Split into sentences (simple regex-based splitter).
3. Create weak labels for each sentence:
   - ACTION / DECISION / QUESTION / INFO (using simple rules).
4. Build a vocabulary from scratch (no pre-trained embeddings).
5. Encode sentences as integer sequences.
6. Stratified train/validation split.
7. Train a small BiLSTM from scratch:
   - Embedding dim = 100
   - Hidden dim = 128
   - 1 LSTM layer, bidirectional
8. Handle class imbalance using class weights in CrossEntropyLoss.
9. Log train loss, val loss, val accuracy each epoch.
10. Print final accuracy and classification report.
"""

import pandas as pd
import re
from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

# ----------------------------
# Basic setup
# ----------------------------

def set_seed(seed: int = 42):
    import random
    import numpy as np
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed(42)

print("PyTorch version:", torch.__version__)
print("GPU available :", torch.cuda.is_available())
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ----------------------------
# Step 1: Load the CSV
# ----------------------------

DATA_PATH = Path("test_df.csv")   # change if needed

if not DATA_PATH.exists():
    raise FileNotFoundError(f"Could not find {DATA_PATH}. Put test_df.csv in this folder.")

df = pd.read_csv(DATA_PATH)

print("\n=== Original DataFrame ===")
print("Shape:", df.shape)
print(df.head(), "\n")
print("Columns:", df.columns.tolist(), "\n")


# ----------------------------
# Step 2: Preprocessing
#   - extract speaker
#   - clean text
#   - split into sentences
# ----------------------------

def split_speaker_and_text(transcript: str):
    """
    Example:
    "Speaker 2: Hello world" -> ("Speaker 2", "Hello world")
    If no "Speaker X:" prefix is present, speaker=None and whole text as utterance.
    """
    if not isinstance(transcript, str):
        return None, ""
    text = transcript.strip()
    m = re.match(r"^(Speaker\s+\d+)\s*:\s*", text, flags=re.IGNORECASE)
    if m:
        speaker = m.group(1).title()
        utterance = text[m.end():].strip()
    else:
        speaker = None
        utterance = text
    return speaker, utterance


def clean_text(text: str) -> str:
    """
    Very light cleaning:
    - remove [laughter], [noise], etc.
    - remove tiny fillers (um, uh, hmm, erm)
    - collapse multiple spaces
    """
    if not isinstance(text, str):
        return ""
    text = re.sub(r"\[.*?\]", " ", text)  # remove [tags]
    text = re.sub(r"\b(um|uh|hmm|erm)\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def split_into_sentences(text: str):
    """
    Very simple rule-based sentence splitter.
    Splits on '.', '?', '!' and trims whitespace.
    It's not perfect, but good enough for this project.
    """
    if not isinstance(text, str) or not text.strip():
        return []
    # ensure space after ., ?, ! so split is cleaner
    text = re.sub(r"([.?!])", r"\1 ", text)
    raw_sents = re.split(r"[.?!]+", text)
    sentences = []
    for s in raw_sents:
        s = s.strip()
        if len(s) > 1:
            sentences.append(s)
    return sentences


# Apply speaker extraction and cleaning to each transcript
df[["speaker", "utterance"]] = df["Transcript"].apply(
    lambda x: pd.Series(split_speaker_and_text(x))
)
df["utterance_clean"] = df["utterance"].apply(clean_text)

print("=== After cleaning & speaker extraction ===")
print(df[["Transcript", "speaker", "utterance_clean"]].head(), "\n")


# Expand to sentence-level DataFrame
rows = []
for _, row in df.iterrows():
    sents = split_into_sentences(row["utterance_clean"])
    for idx, s in enumerate(sents):
        rows.append({
            "Meeting_UID": row["Meeting_UID"],
            "Item_UID": row["Item_UID"],
            "Date": row["Date"],
            "speaker": row["speaker"],
            "sentence_index": idx,
            "sentence": s
        })

sent_df = pd.DataFrame(rows)

print("=== Sentence-level DataFrame ===")
print("Shape:", sent_df.shape)   # this is where you see ~24k sentences
print(sent_df.head(), "\n")


# ----------------------------
# Step 3: Weak labeling with rules
#   (ACTION / DECISION / QUESTION / INFO)
# ----------------------------

LABEL_ACTION = "ACTION"
LABEL_DECISION = "DECISION"
LABEL_QUESTION = "QUESTION"
LABEL_INFO = "INFO"

def rule_based_label(sentence: str) -> str:
    s = sentence.strip()
    s_low = s.lower()

    # QUESTION
    if s.endswith("?") or s_low.startswith((
        "what ", "why ", "who ", "how ", "when ",
        "do we ", "did we ", "can we ", "should we "
    )):
        return LABEL_QUESTION

    # DECISION
    decision_phrases = [
        "we decided", "it is decided", "we have decided",
        "decision is", "is approved", "motion carries",
        "the bill has passed", "the motion has passed",
        "we will proceed", "we will go ahead"
    ]
    for phrase in decision_phrases:
        if phrase in s_low:
            return LABEL_DECISION

    # ACTION
    action_phrases = [
        " will ", " shall ", " need to ", " has to ", " must ",
        "assign to", "assigned to", "action item"
    ]
    for phrase in action_phrases:
        if phrase in s_low:
            return LABEL_ACTION

    # Default
    return LABEL_INFO


sent_df["label_str"] = sent_df["sentence"].apply(rule_based_label)

print("=== Sample sentences with rule-based labels ===")
print(sent_df[["sentence", "label_str"]].head(20), "\n")

print("Label distribution (weak labels):")
print(sent_df["label_str"].value_counts(), "\n")


# ----------------------------
# Step 4: Encode labels, stratified train/val split
# ----------------------------

label2id = {
    LABEL_ACTION: 0,
    LABEL_DECISION: 1,
    LABEL_QUESTION: 2,
    LABEL_INFO: 3
}
id2label = {v: k for k, v in label2id.items()}

sent_df["label"] = sent_df["label_str"].map(label2id)
sent_df = sent_df.dropna(subset=["label"]).reset_index(drop=True)
sent_df["label"] = sent_df["label"].astype(int)

# Stratified split to keep label ratios similar in train and val
train_df, val_df = train_test_split(
    sent_df,
    test_size=0.2,
    random_state=42,
    stratify=sent_df["label"]
)

print("=== Train/Val Split ===")
print("Train size:", train_df.shape)
print("Val size  :", val_df.shape)
print("\nTrain label distribution:")
print(train_df["label_str"].value_counts(normalize=True), "\n")


# ----------------------------
# Step 5: Build vocabulary from scratch
# ----------------------------

def simple_tokenize(text: str):
    # lowercase, split on non-word chars
    return re.findall(r"\w+", text.lower())

word_freq = {}
for sent in train_df["sentence"]:
    for w in simple_tokenize(sent):
        word_freq[w] = word_freq.get(w, 0) + 1

min_freq = 2  # ignore words that appear only once to reduce vocab size
vocab = {"<PAD>": 0, "<UNK>": 1}
for w, f in word_freq.items():
    if f >= min_freq:
        vocab[w] = len(vocab)

vocab_size = len(vocab)
PAD_IDX = vocab["<PAD>"]
UNK_IDX = vocab["<UNK>"]

print("Vocab size:", vocab_size, "\n")

MAX_LEN = 40  # max tokens per sentence

def encode_sentence(text: str, max_len: int = MAX_LEN):
    tokens = simple_tokenize(text)
    ids = [vocab.get(t, UNK_IDX) for t in tokens[:max_len]]
    if len(ids) < max_len:
        ids += [PAD_IDX] * (max_len - len(ids))
    return ids

train_df["input_ids"] = train_df["sentence"].apply(lambda s: encode_sentence(s, MAX_LEN))
val_df["input_ids"]   = val_df["sentence"].apply(lambda s: encode_sentence(s, MAX_LEN))

print("=== Encoded sample ===")
print(train_df[["sentence", "input_ids", "label_str", "label"]].head(), "\n")


# ----------------------------
# Step 6: PyTorch Dataset and DataLoader
# ----------------------------

class SentenceDataset(Dataset):
    def __init__(self, df: pd.DataFrame):
        self.inputs = df["input_ids"].tolist()
        self.labels = df["label"].tolist()

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        x = torch.tensor(self.inputs[idx], dtype=torch.long)
        y = torch.tensor(self.labels[idx], dtype=torch.long)
        return x, y


train_dataset = SentenceDataset(train_df)
val_dataset   = SentenceDataset(val_df)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_loader   = DataLoader(val_dataset, batch_size=64, shuffle=False)

print("Train batches:", len(train_loader))
print("Val batches  :", len(val_loader), "\n")


# ----------------------------
# Step 7: BiLSTM model (small, from scratch)
# ----------------------------

class BiLSTMSentenceClassifier(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_classes, pad_idx):
        super().__init__()
        # Random embeddings learned from scratch
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=pad_idx)
        # Single-layer, bidirectional LSTM
        self.lstm = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )
        # Fully connected output layer: hidden_dim*2 because of bidirectional
        self.fc = nn.Linear(hidden_dim * 2, num_classes)

    def forward(self, x):
        """
        x: (batch_size, seq_len)
        """
        emb = self.embedding(x)                  # (batch, seq_len, embed_dim)
        lstm_out, (h_n, c_n) = self.lstm(emb)    # h_n: (num_layers*2, batch, hidden_dim)

        # Last hidden state from both directions
        h_forward = h_n[-2, :, :]   # (batch, hidden_dim)
        h_backward = h_n[-1, :, :]  # (batch, hidden_dim)
        h_cat = torch.cat([h_forward, h_backward], dim=1)  # (batch, hidden_dim*2)

        logits = self.fc(h_cat)     # (batch, num_classes)
        return logits


embed_dim = 100    # 50–100 as per your description
hidden_dim = 128   # 64–128 as per your description
num_classes = 4

model = BiLSTMSentenceClassifier(
    vocab_size=vocab_size,
    embed_dim=embed_dim,
    hidden_dim=hidden_dim,
    num_classes=num_classes,
    pad_idx=PAD_IDX
).to(device)

print(model, "\n")

# ----------------------------
# Step 8: Class imbalance handling (class weights)
# ----------------------------

# Compute class weights inversely proportional to frequency
label_counts = train_df["label"].value_counts().sort_index()
total = label_counts.sum()
class_weights = [total / (c + 1e-6) for c in label_counts]  # add small epsilon to avoid division by zero
class_weights_tensor = torch.tensor(class_weights, dtype=torch.float32).to(device)

print("Class counts:", label_counts.to_dict())
print("Class weights:", class_weights, "\n")

criterion = nn.CrossEntropyLoss(weight=class_weights_tensor)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)


# ----------------------------
# Step 9: Training & evaluation loop
# ----------------------------

def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0.0
    for x, y in loader:
        x = x.to(device)
        y = y.to(device)

        optimizer.zero_grad()
        logits = model(x)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * x.size(0)
    return total_loss / len(loader.dataset)


def evaluate(model, loader, criterion, device):
    model.eval()
    total_loss = 0.0
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            logits = model(x)
            loss = criterion(logits, y)
            total_loss += loss.item() * x.size(0)

            preds = logits.argmax(dim=1)
            all_preds.extend(preds.cpu().tolist())
            all_labels.extend(y.cpu().tolist())
    avg_loss = total_loss / len(loader.dataset)
    return avg_loss, all_preds, all_labels


num_epochs = 5  # you can tune this
best_val_acc = 0.0

print("=== Training BiLSTM model ===")
for epoch in range(1, num_epochs + 1):
    train_loss = train_one_epoch(model, train_loader, optimizer, criterion, device)
    val_loss, val_preds, val_labels = evaluate(model, val_loader, criterion, device)

    val_acc = accuracy_score(val_labels, val_preds)
    print(f"Epoch {epoch:02d}: "
          f"train_loss={train_loss:.4f}  "
          f"val_loss={val_loss:.4f}  "
          f"val_acc={val_acc:.4f}")

    # Simple "early stopping" style check (just for info, not actually stopping here)
    if val_acc > best_val_acc:
        best_val_acc = val_acc
        torch.save(model.state_dict(), "bilstm_best.pt")

print("\nBest validation accuracy:", best_val_acc)


# ----------------------------
# Step 10: Final evaluation
# ----------------------------

# Load best model (optional)
model.load_state_dict(torch.load("bilstm_best.pt", map_location=device))

val_loss, val_preds, val_labels = evaluate(model, val_loader, criterion, device)
val_acc = accuracy_score(val_labels, val_preds)

print("\n=== Final Evaluation on Validation Set ===")
print("Val loss :", val_loss)
print("Val acc  :", val_acc)

print("\nClassification report:")
print(classification_report(
    val_labels,
    val_preds,
    target_names=[LABEL_ACTION, LABEL_DECISION, LABEL_QUESTION, LABEL_INFO]
))

print("Confusion matrix:")
print(confusion_matrix(val_labels, val_preds))


# ----------------------------
# Helper: Predict label for any sentence
# ----------------------------

def predict_label(sentence: str) -> str:
    model.eval()
    ids = encode_sentence(sentence, MAX_LEN)
    x = torch.tensor(ids, dtype=torch.long).unsqueeze(0).to(device)  # shape (1, seq_len)
    with torch.no_grad():
        logits = model(x)
        pred = logits.argmax(dim=1).item()
    return id2label[pred]


print("\n=== Some manual test sentences ===")
test_sentences = [
    "John will prepare the budget report by next week",
    "We decided to postpone the project launch",
    "Can we get the sales numbers for last quarter?",
    "This report shows the performance of all departments"
]

for s in test_sentences:
    print("-" * 60)
    print("Sentence       :", s)
    print("Predicted label:", predict_label(s))
