"""
Backend for ONE user input paragraph:

- On startup (one-time):
    * Load test_df.csv
    * Build sentence-level data
    * Build weak labels (for stratify only)
    * Create vocabulary exactly like training
    * Rebuild BiLSTM model
    * Load trained weights from bilstm_best.pt

- Then:
    * Ask user to type/paste ONE paragraph (any text).
    * Clean + split into sentences.
    * Predict label for each sentence with BiLSTM.
    * Build a label-aware prompt.
    * Call Ollama llama3.2:3b via HTTP.
    * Print ONE summary for that paragraph.

No loops over Meeting_UIDs.
No batch over full dataset at inference time.
"""

import re
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

import torch
import torch.nn as nn
import requests  # for Ollama HTTP API


# ----------------------------
# Basic setup
# ----------------------------

def set_seed(seed: int = 42):
    import random
    import numpy as np
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


set_seed(42)

print("PyTorch version:", torch.__version__)
print("GPU available :", torch.cuda.is_available())
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ----------------------------
# Paths
# ----------------------------

DATA_PATH = Path("test_df.csv")   # original dataset (for vocab building)
MODEL_PATH = Path("bilstm_best.pt")

if not DATA_PATH.exists():
    raise FileNotFoundError(f"Missing dataset: {DATA_PATH.resolve()}")
if not MODEL_PATH.exists():
    raise FileNotFoundError(f"Missing model file: {MODEL_PATH.resolve()}")

print("\n=== Loading dataset (only to rebuild vocab) ===")
df = pd.read_csv(DATA_PATH)
print("Dataset shape:", df.shape)


# ----------------------------
# Preprocessing helpers (used for dataset + user input)
# ----------------------------

def split_speaker_and_text(transcript: str):
    """
    Extract 'Speaker X' and utterance from lines like:
      'Speaker 2: Hello everyone...' -> ('Speaker 2', 'Hello everyone...')
    If no 'Speaker X:' prefix, speaker=None, utterance=full text.
    """
    if not isinstance(transcript, str):
        return None, ""
    text = transcript.strip()
    m = re.match(r"^(Speaker\s+\d+)\s*:\s*", text, flags=re.IGNORECASE)
    if m:
        speaker = m.group(1).title()
        utterance = text[m.end():].strip()
    else:
        speaker = None
        utterance = text
    return speaker, utterance


def clean_text(text: str) -> str:
    """
    Light cleaning: remove [tags], small fillers, extra spaces.
    """
    if not isinstance(text, str):
        return ""
    text = re.sub(r"\[.*?\]", " ", text)  # remove [laughter], [noise], etc.
    text = re.sub(r"\b(um|uh|hmm|erm)\b", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def split_into_sentences(text: str):
    """
    Simple rule-based sentence splitter on '.', '?', '!'.
    """
    if not isinstance(text, str) or not text.strip():
        return []
    text = re.sub(r"([.?!])", r"\1 ", text)
    raw_sents = re.split(r"[.?!]+", text)
    sentences = []
    for s in raw_sents:
        s = s.strip()
        if len(s) > 1:
            sentences.append(s)
    return sentences


# ----------------------------
# Build sentence-level df from dataset (for vocab only)
# ----------------------------

rows = []
for _, row in df.iterrows():
    spk, utt = split_speaker_and_text(row["Transcript"])
    utt_clean = clean_text(utt)
    sents = split_into_sentences(utt_clean)
    for idx, s in enumerate(sents):
        rows.append({
            "sentence_index": idx,
            "sentence": s
        })

sent_df = pd.DataFrame(rows)
print("Sentence-level rows (for vocab building):", sent_df.shape[0])


# ----------------------------
# Weak labels (same rules as training)
#   Needed only to create label column for stratified split
# ----------------------------

LABEL_ACTION = "ACTION"
LABEL_DECISION = "DECISION"
LABEL_QUESTION = "QUESTION"
LABEL_INFO = "INFO"


def rule_based_label(sentence: str) -> str:
    s = sentence.strip()
    s_low = s.lower()

    # QUESTION
    if s.endswith("?") or s_low.startswith((
        "what ", "why ", "who ", "how ", "when ",
        "do we ", "did we ", "can we ", "should we "
    )):
        return LABEL_QUESTION

    # DECISION
    decision_phrases = [
        "we decided", "it is decided", "we have decided",
        "decision is", "is approved", "motion carries",
        "the bill has passed", "the motion has passed",
        "we will proceed", "we will go ahead"
    ]
    for phrase in decision_phrases:
        if phrase in s_low:
            return LABEL_DECISION

    # ACTION
    action_phrases = [
        " will ", " shall ", " need to ", " has to ", " must ",
        "assign to", "assigned to", "action item"
    ]
    for phrase in action_phrases:
        if phrase in s_low:
            return LABEL_ACTION

    return LABEL_INFO


sent_df["label_str_weak"] = sent_df["sentence"].apply(rule_based_label)

label2id = {
    LABEL_ACTION: 0,
    LABEL_DECISION: 1,
    LABEL_QUESTION: 2,
    LABEL_INFO: 3
}
id2label = {v: k for k, v in label2id.items()}

sent_df["label_weak"] = sent_df["label_str_weak"].map(label2id)
sent_df = sent_df.dropna(subset=["label_weak"]).reset_index(drop=True)
sent_df["label_weak"] = sent_df["label_weak"].astype(int)

print("Weak label distribution (dataset, for info):")
print(sent_df["label_str_weak"].value_counts(), "\n")


# ----------------------------
# Recreate train split & vocab (must match training)
# ----------------------------

train_df, val_df = train_test_split(
    sent_df,
    test_size=0.2,
    random_state=42,
    stratify=sent_df["label_weak"]
)

print("Train rows (for vocab):", train_df.shape[0])


def simple_tokenize(text: str):
    return re.findall(r"\w+", text.lower())


word_freq = {}
for sent in train_df["sentence"]:
    for w in simple_tokenize(sent):
        word_freq[w] = word_freq.get(w, 0) + 1

min_freq = 2  # same as training
vocab = {"<PAD>": 0, "<UNK>": 1}
for w, f in word_freq.items():
    if f >= min_freq:
        vocab[w] = len(vocab)

vocab_size = len(vocab)
PAD_IDX = vocab["<PAD>"]
UNK_IDX = vocab["<UNK>"]

print("Vocab size:", vocab_size, "\n")

MAX_LEN = 40  # must match training


def encode_sentence(text: str, max_len: int = MAX_LEN):
    tokens = simple_tokenize(text)
    ids = [vocab.get(t, UNK_IDX) for t in tokens[:max_len]]
    if len(ids) < max_len:
        ids += [PAD_IDX] * (max_len - len(ids))
    return ids


# ----------------------------
# BiLSTM model (same architecture as training) + load weights
# ----------------------------

class BiLSTMSentenceClassifier(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_classes, pad_idx):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=pad_idx)
        self.lstm = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )
        self.fc = nn.Linear(hidden_dim * 2, num_classes)

    def forward(self, x):
        emb = self.embedding(x)
        lstm_out, (h_n, c_n) = self.lstm(emb)
        h_forward = h_n[-2, :, :]
        h_backward = h_n[-1, :, :]
        h_cat = torch.cat([h_forward, h_backward], dim=1)
        logits = self.fc(h_cat)
        return logits


embed_dim = 100   # same as training
hidden_dim = 128
num_classes = 4

model = BiLSTMSentenceClassifier(
    vocab_size=vocab_size,
    embed_dim=embed_dim,
    hidden_dim=hidden_dim,
    num_classes=num_classes,
    pad_idx=PAD_IDX
).to(device)

model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()

print("Loaded BiLSTM model from:", MODEL_PATH, "\n")


def predict_label_for_sentence(sentence: str) -> str:
    ids = encode_sentence(sentence, MAX_LEN)
    x = torch.tensor(ids, dtype=torch.long).unsqueeze(0).to(device)
    with torch.no_grad():
        logits = model(x)
        pred_id = logits.argmax(dim=1).item()
    return id2label[pred_id]


# ----------------------------
# Ollama HTTP API
# ----------------------------

def call_ollama(prompt: str, model_name: str = "llama3.2:3b") -> str:
    """
    Calls Ollama HTTP API.
    Ollama app must be running and model pulled.
    """
    url = "http://localhost:11434/api/generate"
    payload = {
        "model": model_name,
        "prompt": prompt,
        "stream": False
    }
    try:
        resp = requests.post(url, json=payload, timeout=300)
        resp.raise_for_status()
        data = resp.json()
        return data.get("response", "").strip()
    except Exception as e:
        print("Error calling Ollama API:", e)
        return ""


# ----------------------------
# Build prompt for ONE paragraph (user input)
# ----------------------------

def build_prompt_for_user_sentences(user_meeting_df: pd.DataFrame) -> str:
    """
    user_meeting_df: columns = sentence, pred_label
    """
    actions = user_meeting_df[user_meeting_df["pred_label"] == LABEL_ACTION]["sentence"].tolist()
    decisions = user_meeting_df[user_meeting_df["pred_label"] == LABEL_DECISION]["sentence"].tolist()
    questions = user_meeting_df[user_meeting_df["pred_label"] == LABEL_QUESTION]["sentence"].tolist()
    infos = user_meeting_df[user_meeting_df["pred_label"] == LABEL_INFO]["sentence"].tolist()

    # Limit each group so the prompt doesn't explode
    actions = actions[:10]
    decisions = decisions[:10]
    questions = questions[:10]
    infos = infos[:10]

    lines = []
    lines.append("You are an AI assistant that writes professional minutes of meeting.")
    lines.append("Below are sentences from a single meeting transcript, grouped by predicted categories.")
    lines.append("")

    if decisions:
        lines.append("DECISIONS:")
        for s in decisions:
            lines.append(f"- {s}")
        lines.append("")

    if actions:
        lines.append("ACTION ITEMS:")
        for s in actions:
            lines.append(f"- {s}")
        lines.append("")

    if questions:
        lines.append("QUESTIONS ASKED:")
        for s in questions:
            lines.append(f"- {s}")
        lines.append("")

    if infos:
        lines.append("GENERAL DISCUSSION / INFO:")
        for s in infos:
            lines.append(f"- {s}")
        lines.append("")

    lines.append(
        "Using the above sentences, write clear, concise Minutes of Meeting with the "
        "following structure:\n"
        "1. Short summary (2–3 lines)\n"
        "2. Key decisions (bullet points)\n"
        "3. Action items (who will do what and by when, if mentioned)\n"
        "4. Important discussion points\n"
        "Do not invent facts that are not implied by the sentences."
    )

    return "\n".join(lines)


# ----------------------------
# MAIN: get ONE paragraph from user, summarize it
# ----------------------------

print("=== Ready for single paragraph input ===")
print("Type or paste ONE paragraph of meeting transcript.")
print("It can be simple English text (speakers optional).")
print("When done, press Enter, then Ctrl+Z (Windows) or Ctrl+D (Linux/Mac) and Enter.\n")

print("Paste your paragraph below:\n")

# Read multiline input until EOF (Ctrl+Z then Enter on Windows)
import sys
user_text = sys.stdin.read().strip()

if not user_text:
    print("No input provided. Exiting.")
    sys.exit(0)

# Process user paragraph:
# 1) Clean whole text
# 2) Split into sentences
user_clean = clean_text(user_text)
sentences = split_into_sentences(user_clean)

if not sentences:
    print("No sentences could be extracted from your input. Exiting.")
    sys.exit(0)

user_rows = []
for idx, s in enumerate(sentences):
    label = predict_label_for_sentence(s)
    user_rows.append({"sentence_index": idx, "sentence": s, "pred_label": label})

user_meeting_df = pd.DataFrame(user_rows)

print("\nDetected sentences and predicted labels (first few):")
print(user_meeting_df.head(15))
print()

prompt = build_prompt_for_user_sentences(user_meeting_df)

print("Calling Ollama (llama3.2:3b) to generate summary...\n")
summary_text = call_ollama(prompt, model_name="llama3.2:3b")

print("\n================= GENERATED SUMMARY =================\n")
print(summary_text)
print("\n======================================================\n")
